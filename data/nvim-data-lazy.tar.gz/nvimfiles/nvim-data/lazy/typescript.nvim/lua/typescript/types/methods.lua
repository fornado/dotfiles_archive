--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
____exports.Methods = Methods or ({})
____exports.Methods.CODE_ACTION = "textDocument/codeAction"
____exports.Methods.DEFINITION = "textDocument/definition"
____exports.Methods.EXECUTE_COMMAND = "workspace/executeCommand"
____exports.TypescriptMethods = TypescriptMethods or ({})
____exports.TypescriptMethods.RENAME = "_typescript.rename"
return ____exports
