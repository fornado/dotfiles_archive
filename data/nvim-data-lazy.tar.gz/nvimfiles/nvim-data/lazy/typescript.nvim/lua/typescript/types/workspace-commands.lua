--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
____exports.WorkspaceCommands = WorkspaceCommands or ({})
____exports.WorkspaceCommands.APPLY_RENAME_FILE = "_typescript.applyRenameFile"
____exports.WorkspaceCommands.GO_TO_SOURCE_DEFINITION = "_typescript.goToSourceDefinition"
return ____exports
