export enum WorkspaceCommands {
  APPLY_RENAME_FILE = "_typescript.applyRenameFile",
  GO_TO_SOURCE_DEFINITION = "_typescript.goToSourceDefinition",
}
