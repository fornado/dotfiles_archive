export enum Methods {
  CODE_ACTION = "textDocument/codeAction",
  DEFINITION = "textDocument/definition",
  EXECUTE_COMMAND = "workspace/executeCommand",
}

export enum TypescriptMethods {
  RENAME = "_typescript.rename",
}
