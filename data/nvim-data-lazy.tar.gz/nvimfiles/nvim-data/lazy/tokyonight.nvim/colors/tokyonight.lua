require("tokyonight")._load()
