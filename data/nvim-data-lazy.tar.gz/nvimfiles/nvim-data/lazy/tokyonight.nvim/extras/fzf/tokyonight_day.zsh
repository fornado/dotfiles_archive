export FZF_DEFAULT_OPTS="$FZF_DEFAULT_OPTS \
--color=fg:#3760bf,bg:#e1e2e7,hl:#b15c00 \
--color=fg+:#3760bf,bg+:#c4c8da,hl+:#b15c00 \
--color=info:#2e7de9,prompt:#007197,pointer:#007197 \
--color=marker:#587539,spinner:#587539,header:#587539"
