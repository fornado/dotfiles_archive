-- SPDX-FileCopyrightText: 2022 Michael Weimann <mail@michael-weimann.eu>
--
-- SPDX-License-Identifier: MIT

return {
  quote_prompt = require("telescope-live-grep-args.actions.quote_prompt"),
}
